.. {#openvino_docs_OV_UG_lpt_SplitTransformation}

SplitTransformation transformation
==================================

ov::pass::low_precision::SplitTransformation class represents the `Split` operation transformation.

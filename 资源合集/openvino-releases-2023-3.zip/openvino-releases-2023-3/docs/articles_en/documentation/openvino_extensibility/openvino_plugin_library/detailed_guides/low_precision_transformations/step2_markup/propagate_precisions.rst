.. {#openvino_docs_OV_UG_lpt_PropagatePrecisions}

PropagatePrecisions transformation
==================================

ov::pass::low_precision::PropagatePrecisions class represents the `PropagatePrecisions` transformation.

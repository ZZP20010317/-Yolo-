.. {#openvino_docs_OV_UG_lpt_NormalizeL2Transformation}

NormalizeL2Transformation transformation
========================================

ov::pass::low_precision::NormalizeL2Transformation class represents the `NormalizeL2` operation transformation.

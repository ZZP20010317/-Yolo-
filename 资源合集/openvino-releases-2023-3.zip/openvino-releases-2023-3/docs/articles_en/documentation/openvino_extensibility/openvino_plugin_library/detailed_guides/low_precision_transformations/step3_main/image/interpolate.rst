.. {#openvino_docs_OV_UG_lpt_InterpolateTransformation}

InterpolateTransformation transformation
========================================

ov::pass::low_precision::InterpolateTransformation class represents the `Interpolate` operation transformation.

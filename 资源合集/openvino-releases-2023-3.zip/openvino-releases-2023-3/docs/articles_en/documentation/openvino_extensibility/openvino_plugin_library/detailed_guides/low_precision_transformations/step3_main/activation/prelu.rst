.. {#openvino_docs_OV_UG_lpt_PReluTransformation}

PReluTransformation transformation
==================================

ov::pass::low_precision::PReluTransformation class represents the `PRelu` operation transformation.

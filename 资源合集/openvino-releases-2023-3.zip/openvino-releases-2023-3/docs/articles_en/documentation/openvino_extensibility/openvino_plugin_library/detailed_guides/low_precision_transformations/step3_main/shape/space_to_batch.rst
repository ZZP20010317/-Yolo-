.. {#openvino_docs_OV_UG_lpt_SpaceToBatchTransformation}

SpaceToBatchTransformation transformation
=========================================

ngraph::pass::low_precision::SpaceToBatchTransformation class represents the `SpaceToBatch` operation transformation.

.. {#openvino_docs_OV_UG_lpt_CreatePrecisionsDependentAttribute}

CreatePrecisionsDependentAttribute transformation
=================================================

ov::pass::low_precision::CreatePrecisionsDependentAttribute class represents the `CreatePrecisionsDependentAttribute` transformation.

.. {#openvino_docs_OV_UG_lpt_BatchToSpaceTransformation}

BatchToSpaceTransformation transformation
=========================================

ngraph::pass::low_precision::BatchToSpaceTransformation class represents the `BatchToSpace` operation transformation.

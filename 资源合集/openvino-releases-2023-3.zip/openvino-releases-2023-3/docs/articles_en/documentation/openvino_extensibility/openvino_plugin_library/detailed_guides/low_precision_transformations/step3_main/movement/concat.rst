.. {#openvino_docs_OV_UG_lpt_ConcatTransformation}

ConcatTransformation transformation
===================================

ov::pass::low_precision::ConcatTransformation class represents the `Concat` operation transformation.

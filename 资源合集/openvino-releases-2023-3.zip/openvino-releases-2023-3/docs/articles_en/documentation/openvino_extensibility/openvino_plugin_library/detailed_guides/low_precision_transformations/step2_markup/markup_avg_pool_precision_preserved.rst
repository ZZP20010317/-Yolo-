.. {#openvino_docs_OV_UG_lpt_MarkupAvgPoolPrecisionPreserved}

MarkupAvgPoolPrecisionPreserved transformation
==============================================

ov::pass::low_precision::MarkupAvgPoolPrecisionPreserved class represents the `MarkupAvgPoolPrecisionPreserved` transformation.

.. {#openvino_docs_OV_UG_lpt_GatherTransformation}

GatherTransformation transformation
===================================

ov::pass::low_precision::GatherTransformation class represents the `Gather` operation transformation.

.. {#openvino_docs_OV_UG_lpt_MultiplyPartialTransformation}

MultiplyTransformation transformation
=====================================

ov::pass::low_precision::MultiplyPartialTransformation class represents the `MultiplyPartial` operation transformation.
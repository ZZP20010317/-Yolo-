.. {#openvino_docs_OV_UG_lpt_ReduceMeanTransformation}

ReduceMeanTransformation transformation
=======================================

ov::pass::low_precision::ReduceMeanTransformation class represents the `ReduceMean` operation transformation.

.. {#openvino_docs_OV_UG_lpt_FuseConvertTransformation}

FuseConvertTransformation transformation
========================================

ov::pass::low_precision::FuseConvertTransformation class represents the `FuseConvertTransformation` transformation.

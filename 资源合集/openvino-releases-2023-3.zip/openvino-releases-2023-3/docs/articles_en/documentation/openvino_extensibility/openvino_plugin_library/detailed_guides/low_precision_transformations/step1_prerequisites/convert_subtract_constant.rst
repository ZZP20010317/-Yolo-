.. {#openvino_docs_OV_UG_lpt_ConvertSubtractConstant}

ConvertSubtractConstant transformation
======================================

ov::pass::low_precision::ConvertSubtractConstant class represents the `ConvertSubtractConstant` transformation.

.. {#openvino_docs_OV_UG_lpt_AlignQuantizationParameters}

AlignQuantizationParameters transformation
==========================================

ov::pass::low_precision::AlignQuantizationParameters class represents the `AlignQuantizationParameters` transformation.

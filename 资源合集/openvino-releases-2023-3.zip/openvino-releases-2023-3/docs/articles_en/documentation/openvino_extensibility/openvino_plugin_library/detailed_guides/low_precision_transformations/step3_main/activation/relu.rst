.. {#openvino_docs_OV_UG_lpt_ReluTransformation}

ReluTransformation transformation
=================================

ov::pass::low_precision::ReluTransformation class represents the `Relu` operation transformation.

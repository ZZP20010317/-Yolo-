.. {#openvino_docs_OV_UG_lpt_MarkupPerTensorQuantization}

MarkupPerTensorQuantization transformation
==========================================

ov::pass::low_precision::MarkupPerTensorQuantization class represents the `MarkupPerTensorQuantization` transformation.

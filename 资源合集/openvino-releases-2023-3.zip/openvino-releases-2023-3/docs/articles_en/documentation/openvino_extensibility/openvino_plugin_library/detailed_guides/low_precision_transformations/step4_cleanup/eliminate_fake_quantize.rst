.. {#openvino_docs_OV_UG_lpt_EliminateFakeQuantizeTransformation}

EliminateFakeQuantizeTransformation transformation
==================================================

ov::pass::low_precision::EliminateFakeQuantizeTransformation class represents the `EliminateFakeQuantizeTransformation` transformation.

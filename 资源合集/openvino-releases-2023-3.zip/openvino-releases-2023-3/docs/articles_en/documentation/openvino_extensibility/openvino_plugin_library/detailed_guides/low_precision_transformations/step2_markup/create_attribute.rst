.. {#openvino_docs_OV_UG_lpt_CreateAttribute}

CreateAttribute transformation
==============================

ov::pass::low_precision::CreateAttribute class represents the `CreateAttribute` transformation.
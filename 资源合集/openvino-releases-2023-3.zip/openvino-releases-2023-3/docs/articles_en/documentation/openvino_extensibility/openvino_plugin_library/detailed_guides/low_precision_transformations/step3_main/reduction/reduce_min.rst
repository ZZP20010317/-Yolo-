.. {#openvino_docs_OV_UG_lpt_ReduceMinTransformation}

ReduceMinTransformation transformation
======================================

ov::pass::low_precision::ReduceMinTransformation class represents the `ReduceMin` operation transformation.
